window.onload = function(){
function mouseOver() {
    document.getElementById("qa").style.color = "blue";
    console.log("Its Red Now");
  }
  
  function mouseOut() {
    document.getElementById("qa").style.color = "black";
    console.log("Its Black Now");
    }}